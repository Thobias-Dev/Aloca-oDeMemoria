﻿using Alocacao_Memoria.Util;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;

namespace Util
{
    public class Arquivo
    {
        private StreamWriter escritor = null;
        private List<string> algoritmos = new List<string>();

        public List<object> LerArquivo(string FILENAME)
        {
            StreamReader br = null;
            FileStream fr = null;
            List<Memoria> mList = new List<Memoria>();
            List<Processo> ptList = new List<Processo>();

            try
            {
                fr = new FileStream(FILENAME, FileMode.Open);
                br = new StreamReader(fr);

                string sCurrentLine;
                int idProcesso = 1;

                while ((sCurrentLine = br.ReadLine()) != null)
                {
                    if (!string.IsNullOrWhiteSpace(sCurrentLine))
                    {
                        if (sCurrentLine.Contains(" "))
                        {
                            string[] parts = sCurrentLine.Split(' ');
                            Memoria m = new Memoria(parts[0], int.Parse(parts[1]), int.Parse(parts[2]), 0);
                            mList.Add(m);
                        }
                        else
                        {
                            Processo p = new Processo(int.Parse(sCurrentLine), 0, 0, idProcesso);
                            ptList.Add(p);
                            idProcesso++;
                        }
                    }
                }

                if (br != null)
                    br.Close();

                if (fr != null)
                    fr.Close();

                if (mList.Count > 0)
                {
                    return new List<object>(mList);
                }
                else
                {
                    return new List<object>(ptList);
                }
            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message);
                return null;
            }
        }

        public void ArquivoSaida(string texto, string algoritmo)
        {
            try
            {
                if (!File.Exists("saida/" + algoritmo + ".txt") && !algoritmos.Contains(algoritmo))
                {
                    File.Create("saida/" + algoritmo + ".txt").Close();
                    escritor = new StreamWriter("saida/" + algoritmo + ".txt");
                    algoritmos.Add(algoritmo);
                }

                escritor.WriteLine(texto);
                escritor.Flush();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }
        }
    }
}


