﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alocacao_Memoria.Util
{
        public class Memoria
        {
            private int idProcesso;
            private string estado;
            private int inicio;
            private int tamanho;
        internal int Tamanho;

        public object Estado { get; internal set; }

        public Memoria(string estado, int inicio, int tamanho, int id)
            {
                this.idProcesso = id;
                this.estado = estado;
                this.inicio = inicio;
                this.tamanho = tamanho;
            }

            public int GetIdProcesso()
            {
                return idProcesso;
            }

            public void SetIdProcesso(int id)
            {
                this.idProcesso = id;
            }

            public string GetEstado()
            {
                return estado;
            }

            public void SetEstado(string estado)
            {
                this.estado = estado;
            }

            public int GetInicio()
            {
                return inicio;
            }

            public void SetInicio(int inicio)
            {
                this.inicio = inicio;
            }

            public int GetTamanho()
            {
                return tamanho;
            }

            public void SetTamanho(int tamanho)
            {
                this.tamanho = tamanho;
            }

            public override string ToString()
            {
                return "(id processo:" + idProcesso + ")," + estado + "," + inicio + "," + tamanho;
            }
        }
    }
