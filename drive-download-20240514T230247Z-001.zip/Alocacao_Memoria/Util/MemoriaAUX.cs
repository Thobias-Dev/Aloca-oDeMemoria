﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alocacao_Memoria.UtiL
 {
        public class MemoriaAUX
        {
            private int idP;
            private int idM;
            private int tamanho;

            public MemoriaAUX(int idp, int tamanho, int idm)
            {
                SetIdP(idp);
                SetTamanho(tamanho);
                SetIdm(idm);
            }

            public MemoriaAUX()
            {

            }

            public int GetIdp()
            {
                return idP;
            }
            public void SetIdP(int id)
            {
                this.idP = id;
            }
            public int GetIdm()
            {
                return idM;
            }
            public void SetIdm(int id)
            {
                this.idM = id;
            }
            public int GetTamanho()
            {
                return tamanho;
            }
            public void SetTamanho(int tamanho)
            {
                this.tamanho = tamanho;
            }

            public override string ToString()
            {
                return "MemoriaAUX [idP=" + idP + ", idM=" + idM + ", tamanho=" + tamanho + "]";
            }
        }
    }
