﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alocacao_Memoria.Util
{
    public class Processo
    {
        private int id;
        private int computacao;
        private int alocado;
        private int visitado;

        public Processo(int computacao, int alocado, int visitado, int id)
        {
            this.id = id;
            this.computacao = computacao;
            this.alocado = alocado;
            this.visitado = visitado;
        }

        public Processo()
        {

        }

        public int GetId()
        {
            return id;
        }

        public void SetId(int id)
        {
            this.id = id;
        }

        public int GetComputacao()
        {
            return computacao;
        }

        public void SetComputacao(int computacao)
        {
            this.computacao = computacao;
        }

        public int GetAlocado()
        {
            return alocado;
        }

        public void SetAlocado(int alocado)
        {
            this.alocado = alocado;
        }

        public int GetVisitado()
        {
            return visitado;
        }

        public void SetVisitado(int visitado)
        {
            this.visitado = visitado;
        }

        public override string ToString()
        {
            return "Processo [id=" + id + ", computacao=" + computacao + ", alocado=" + alocado + ", visitado=" + visitado + "]";
        }
    }
}