﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alocacao_Memoria.Util
{
    public class ProcessoN
    {
        private int id;
        private int tamanho;

        public ProcessoN(int id, int tamanho)
        {
            SetId(id);
            SetTamanho(tamanho);
        }

        public ProcessoN()
        {

        }

        public int GetId()
        {
            return id;
        }
        public void SetId(int id)
        {
            this.id = id;
        }
        public int GetTamanho()
        {
            return tamanho;
        }
        public void SetTamanho(int tamanho)
        {
            this.tamanho = tamanho;
        }

        public override string ToString()
        {
            return "id: " + id + ", tamanho: " + tamanho;
        }
    }
}
