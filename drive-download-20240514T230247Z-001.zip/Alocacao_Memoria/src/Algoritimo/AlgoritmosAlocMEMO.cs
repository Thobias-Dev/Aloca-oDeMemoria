﻿/*using Alocacao_Memoria.Util;
using Alocacao_Memoria.UtiL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Util;

namespace Alocacao_Memoria.src.Algoritimo
{
    public class AlgoritmosAlocMEMO
    {
        private const string txtMemoria = "entrada/entrada_memoria.txt";
        private const string txtProcessos = "entrada/entrada_processos.txt";
        private static Arquivo a = new Arquivo();
        private static List<Memoria> MemoriaLIDA = new List<Memoria>();
        private static List<Processo> ProcessosLIDOS = new List<Processo>();
        private static List<ProcessoN> ProcessosNALOCADOS = new List<ProcessoN>();

        public static void Main(string[] args)
        {
            Console.WriteLine("PARA RODAR NOVAMENTE O PROGRAMA");
            Console.WriteLine("DELETE TODOS OS ARQUIVOS DE SAIDA");
            Console.WriteLine("");

            ResetDATA(MemoriaLIDA);
            Console.WriteLine("Rodando Frist Fit...");
            FristFIT(MemoriaLIDA, ProcessosLIDOS);
            Console.WriteLine("Terminado");
            Console.WriteLine("");
            ResetDATA(MemoriaLIDA);
            Console.WriteLine("Rodando Next Fit...");
            NextFIT(MemoriaLIDA, ProcessosLIDOS);
            Console.WriteLine("Terminado");
            Console.WriteLine("");
            ResetDATA(MemoriaLIDA);
            Console.WriteLine("Rodando Best Fit...");
            BestFIT(MemoriaLIDA, ProcessosLIDOS);
            Console.WriteLine("Terminado");
            Console.WriteLine("");
            ResetDATA(MemoriaLIDA);
            Console.WriteLine("Rodando Worst Fit...");
            WorstFIT(MemoriaLIDA, ProcessosLIDOS);
            Console.WriteLine("Terminado");

            Console.WriteLine("");
            ResetDATA(MemoriaLIDA);

            Console.WriteLine("PARA RODAR NOVAMENTE O PROGRAMA");
            Console.WriteLine("DELETE TODOS OS ARQUIVOS DE SAIDA");
        }

        public static void FristFIT(List<Memoria> Memoria, List<Processo> Processos)
        {
            int tamanhoM = -1;
            ProcessoN auxN = new ProcessoN();

            foreach (Processo processo in Processos)
            {
                foreach (Memoria memoriaI in Memoria)
                {
                    tamanhoM = memoriaI.GetTamanho();
                    tamanhoM = (tamanhoM < 0 ? -tamanhoM : tamanhoM);

                    if (memoriaI.GetEstado().Equals("H") && processo.GetComputacao() <= tamanhoM && processo.GetAlocado() == 0)
                    {
                        memoriaI.SetEstado("P");
                        memoriaI.SetIdProcesso(processo.GetId());
                        processo.SetAlocado(1);
                    }
                }
            }

            foreach (Processo p in Processos)
            {
                if (p.GetAlocado() == 0)
                {
                    auxN.SetId(p.GetId());
                    auxN.SetTamanho(p.GetComputacao());
                    ProcessosNALOCADOS.Add(auxN);
                }
                auxN = new ProcessoN();
            }

            EscreverArquivo("FRIST-FIT");
        }

        public static void NextFIT(List<Memoria> Memoria, List<Processo> Processos)
        {
            int tamanhoM = -1;
            ProcessoN auxN = new ProcessoN();
            int num = 0;

            foreach (Processo processo in Processos)
            {
                for (int i = num; i < Memoria.Count; i++)
                {
                    tamanhoM = Memoria[i].GetTamanho();
                    tamanhoM = (tamanhoM < 0 ? -tamanhoM : tamanhoM);

                    if (Memoria[i].GetEstado().Equals("H") && processo.GetComputacao() <= tamanhoM && processo.GetAlocado() == 0)
                    {
                        Memoria[i].SetEstado("P");
                        Memoria[i].SetIdProcesso(processo.GetId());
                        processo.SetAlocado(1);
                        num = i;
                    }

                    if (i + 1 == Memoria.Count)
                    {
                        num = 0;
                    }
                }
            }

            foreach (Processo p in Processos)
            {
                if (p.GetAlocado() == 0)
                {
                    auxN.SetId(p.GetId());
                    auxN.SetTamanho(p.GetComputacao());
                    ProcessosNALOCADOS.Add(auxN);
                }
                auxN = new ProcessoN();
            }

            EscreverArquivo("NEXT-FIT");
        }

        public static void BestFIT(List<Memoria> Memoria, List<Processo> Processos)
        {
            bool key = false;
            int tamanhoMV = -1;
            ProcessoN auxN = new ProcessoN();
            List<MemoriaAUX> MemoriaV = new List<MemoriaAUX>();
            MemoriaAUX auxMV = new MemoriaAUX();

            for (int i = 0; i < Processos.Count; i++)
            {
                foreach (Memoria memoria in Memoria)
                {
                    if (memoria.GetEstado().Equals("H") && Processos[i].GetComputacao() <= memoria.GetTamanho() && Processos[i].GetAlocado() == 0)
                    {
                        int x = memoria.GetTamanho();
                        int y = Processos[i].GetComputacao();
                        tamanhoMV = x - y;
                        auxMV.SetIdP(Processos[i].GetId());
                        auxMV.SetIdm(Memoria.IndexOf(memoria));
                        auxMV.SetTamanho(tamanhoMV);
                        MemoriaV.Add(auxMV);
                        auxMV = new MemoriaAUX();
                        key = true;
                    }
                }

                if (Processos[i].GetAlocado() == 0 && key == true)
                {
                    auxMV = MemoriaV.Find(p => p.GetTamanho() == MemoriaV.Min(min => min.GetTamanho()));
                    Processos[i].SetAlocado(1);
                    int idPR = auxMV.GetIdp();
                    int idME = auxMV.GetIdm();
                    Memoria[idME].SetIdProcesso(idPR);
                    Memoria[idME].SetEstado("P");
                    auxMV = new MemoriaAUX();
                    MemoriaV.Clear();
                    key = false;
                }
            }

            foreach (Processo p in Processos)
            {
                if (p.GetAlocado() == 0)
                {
                    auxN = new ProcessoN(p.GetId(), p.GetComputacao());
                    ProcessosNALOCADOS.Add(auxN);
                }
            }

            EscreverArquivo("BEST-FIT");
        }

        public static void WorstFIT(List<Memoria> Memoria, List<Processo> Processos)
        {
            bool key = false;
            int tamanhoMV = -1;
            ProcessoN auxN = new ProcessoN();
            List<MemoriaAUX> MemoriaV = new List<MemoriaAUX>();
            MemoriaAUX auxMV = new MemoriaAUX();

            for (int i = 0; i < Processos.Count; i++)
            {
                foreach (Memoria memoria in Memoria)
                {
                    if (memoria.GetEstado().Equals("H") && Processos[i].GetComputacao() <= memoria.GetTamanho() && Processos[i].GetAlocado() == 0)
                    {
                        int x = memoria.GetTamanho();
                        int y = Processos[i].GetComputacao();
                        tamanhoMV = x - y;
                        auxMV.SetIdP(Processos[i].GetId());
                        auxMV.SetIdm(Memoria.IndexOf(memoria));
                        auxMV.SetTamanho(tamanhoMV);
                        MemoriaV.Add(auxMV);
                        auxMV = new MemoriaAUX();
                        key = true;
                    }
                }

                if (Processos[i].GetAlocado() == 0 && key == true)
                {
                    auxMV = MemoriaV.Find(p => p.GetTamanho() == MemoriaV.Max(max => max.GetTamanho()));
                    Processos[i].SetAlocado(1);
                    int idPR = auxMV.GetIdp();
                    int idME = auxMV.GetIdm();
                    Memoria[idME].SetIdProcesso(idPR);
                    Memoria[idME].SetEstado("P");
                    auxMV = new MemoriaAUX();
                    MemoriaV.Clear();
                    key = false;
                }
            }

            foreach (Processo p in Processos)
            {
                if (p.GetAlocado() == 0)
                {
                    auxN = new ProcessoN(p.GetId(), p.GetComputacao());
                    ProcessosNALOCADOS.Add(auxN);
                }
            }

            EscreverArquivo("WORST-FIT");
        }

        public static void EscreverArquivo(string algoritmo)
        {
            a.ArquivoSaida("Algoritmo " + algoritmo + "\r\n", algoritmo);

            foreach (Memoria m in MemoriaLIDA)
            {
                a.ArquivoSaida(m.ToString(), algoritmo);
            }

            a.ArquivoSaida("\r\nPROCESSOS NÃO ALOCADOS / TAMANHO", algoritmo.ToString());


            foreach (ProcessoN pnl in ProcessosNALOCADOS)
            {
                a.ArquivoSaida(pnl.ToString(), algoritmo);
            }
        }

        public static void ResetDATA(List<Memoria> memoriaLIDA)
        {
            memoriaLIDA = new List<Memoria>((IEnumerable<Memoria>)a.LerArquivo(txtMemoria));
            ProcessosLIDOS = new List<Processo>((IEnumerable<Processo>)a.LerArquivo(txtProcessos));
            ProcessosNALOCADOS = new List<ProcessoN>();
        }
    }
}*/

using System;
using System.Collections.Generic;
using System.Linq;
using Alocacao_Memoria.Util;
using Alocacao_Memoria.UtiL;
using Util;

namespace Alocacao_Memoria.src.Algoritimo
{
    public class AlgoritmosAlocMEMO
    {
        private const string txtMemoria = "C:/documento/thobias/arquivoum.txt";
        private const string txtProcessos = "C:/documento/thobias/arquivodois.txt";
        private static Arquivo a = new Arquivo();
        private static List<Memoria> MemoriaLIDA;
        private static List<Processo> ProcessosLIDOS = new List<Processo>();
        private static List<ProcessoN> ProcessosNALOCADOS = new List<ProcessoN>();

        public static void Main(string[] args)
        {
            Console.WriteLine("PARA RODAR NOVAMENTE O PROGRAMA");
            Console.WriteLine("DELETE TODOS OS ARQUIVOS DE SAIDA");
            Console.WriteLine("");

            ResetDATA();
            Console.WriteLine("Rodando Frist Fit...");
            FristFIT(MemoriaLIDA, ProcessosLIDOS);
            Console.WriteLine("Terminado");
            Console.WriteLine("");
            ResetDATA();
            Console.WriteLine("Rodando Next Fit...");
            NextFIT(MemoriaLIDA, ProcessosLIDOS);
            Console.WriteLine("Terminado");
            Console.WriteLine("");
            ResetDATA();
            Console.WriteLine("Rodando Best Fit...");
            BestFIT(MemoriaLIDA, ProcessosLIDOS);
            Console.WriteLine("Terminado");
            Console.WriteLine("");
            ResetDATA();
            Console.WriteLine("Rodando Worst Fit...");
            WorstFIT(MemoriaLIDA, ProcessosLIDOS);
            Console.WriteLine("Terminado");

            Console.WriteLine("");
            ResetDATA();

            Console.WriteLine("PARA RODAR NOVAMENTE O PROGRAMA");
            Console.WriteLine("DELETE TODOS OS ARQUIVOS DE SAIDA");
        }

        public static void FristFIT(List<Memoria> Memoria, List<Processo> Processos)
        {
            int tamanhoM = -1;
            ProcessoN auxN = new ProcessoN();

            foreach (Processo processo in Processos)
            {
                foreach (Memoria memoriaI in Memoria)
                {
                    tamanhoM = memoriaI.GetTamanho();
                    tamanhoM = (tamanhoM < 0 ? -tamanhoM : tamanhoM);

                    if (memoriaI.GetEstado().Equals("H") && processo.GetComputacao() <= tamanhoM && processo.GetAlocado() == 0)
                    {
                        memoriaI.SetEstado("P");
                        memoriaI.SetIdProcesso(processo.GetId());
                        processo.SetAlocado(1);
                    }
                }
            }

            foreach (Processo p in Processos)
            {
                if (p.GetAlocado() == 0)
                {
                    auxN.SetId(p.GetId());
                    auxN.SetTamanho(p.GetComputacao());
                    ProcessosNALOCADOS.Add(auxN);
                }
                auxN = new ProcessoN();
            }

            EscreverArquivo("FRIST-FIT");
        }

        public static void NextFIT(List<Memoria> Memoria, List<Processo> Processos)
        {
            int tamanhoM = -1;
            ProcessoN auxN = new ProcessoN();
            int num = 0;

            foreach (Processo processo in Processos)
            {
                for (int i = num; i < Memoria.Count; i++)
                {
                    tamanhoM = Memoria[i].GetTamanho();
                    tamanhoM = (tamanhoM < 0 ? -tamanhoM : tamanhoM);

                    if (Memoria[i].GetEstado().Equals("H") && processo.GetComputacao() <= tamanhoM && processo.GetAlocado() == 0)
                    {
                        Memoria[i].SetEstado("P");
                        Memoria[i].SetIdProcesso(processo.GetId());
                        processo.SetAlocado(1);
                        num = i;
                    }

                    if (i + 1 == Memoria.Count)
                    {
                        num = 0;
                    }
                }
            }

            foreach (Processo p in Processos)
            {
                if (p.GetAlocado() == 0)
                {
                    auxN.SetId(p.GetId());
                    auxN.SetTamanho(p.GetComputacao());
                    ProcessosNALOCADOS.Add(auxN);
                }
                auxN = new ProcessoN();
            }

            EscreverArquivo("NEXT-FIT");
        }

        public static void BestFIT(List<Memoria> Memoria, List<Processo> Processos)
        {
            bool key = false;
            int tamanhoMV = -1;
            ProcessoN auxN = new ProcessoN();
            List<MemoriaAUX> MemoriaV = new List<MemoriaAUX>();
            MemoriaAUX auxMV = new MemoriaAUX();

            for (int i = 0; i < Processos.Count; i++)
            {
                foreach (Memoria memoria in Memoria)
                {
                    if (memoria.GetEstado().Equals("H") && Processos[i].GetComputacao() <= memoria.GetTamanho() && Processos[i].GetAlocado() == 0)
                    {
                        int x = memoria.GetTamanho();
                        int y = Processos[i].GetComputacao();
                        tamanhoMV = x - y;
                        auxMV.SetIdP(Processos[i].GetId());
                        auxMV.SetIdm(Memoria.IndexOf(memoria));
                        auxMV.SetTamanho(tamanhoMV);
                        MemoriaV.Add(auxMV);
                        auxMV = new MemoriaAUX();
                        key = true;
                    }
                }

                if (Processos[i].GetAlocado() == 0 && key == true)
                {
                    auxMV = MemoriaV.Find(p => p.GetTamanho() == MemoriaV.Min(min => min.GetTamanho()));
                    Processos[i].SetAlocado(1);
                    int idPR = auxMV.GetIdp();
                    int idME = auxMV.GetIdm();
                    Memoria[idME].SetIdProcesso(idPR);
                    Memoria[idME].SetEstado("P");
                    auxMV = new MemoriaAUX();
                    MemoriaV.Clear();
                    key = false;
                }
            }

            foreach (Processo p in Processos)
            {
                if (p.GetAlocado() == 0)
                {
                    auxN = new ProcessoN(p.GetId(), p.GetComputacao());
                    ProcessosNALOCADOS.Add(auxN);
                }
            }

            EscreverArquivo("BEST-FIT");
        }

        public static void WorstFIT(List<Memoria> Memoria, List<Processo> Processos)
        {
            bool key = false;
            int tamanhoMV = -1;
            ProcessoN auxN = new ProcessoN();
            List<MemoriaAUX> MemoriaV = new List<MemoriaAUX>();
            MemoriaAUX auxMV = new MemoriaAUX();

            for (int i = 0; i < Processos.Count; i++)
            {
                foreach (Memoria memoria in Memoria)
                {
                    if (memoria.GetEstado().Equals("H") && Processos[i].GetComputacao() <= memoria.GetTamanho() && Processos[i].GetAlocado() == 0)
                    {
                        int x = memoria.GetTamanho();
                        int y = Processos[i].GetComputacao();
                        tamanhoMV = x - y;
                        auxMV.SetIdP(Processos[i].GetId());
                        auxMV.SetIdm(Memoria.IndexOf(memoria));
                        auxMV.SetTamanho(tamanhoMV);
                        MemoriaV.Add(auxMV);
                        auxMV = new MemoriaAUX();
                        key = true;
                    }
                }

                if (Processos[i].GetAlocado() == 0 && key == true)
                {
                    auxMV = MemoriaV.Find(p => p.GetTamanho() == MemoriaV.Max(max => max.GetTamanho()));
                    Processos[i].SetAlocado(1);
                    int idPR = auxMV.GetIdp();
                    int idME = auxMV.GetIdm();
                    Memoria[idME].SetIdProcesso(idPR);
                    Memoria[idME].SetEstado("P");
                    auxMV = new MemoriaAUX();
                    MemoriaV.Clear();
                    key = false;
                }
            }

            foreach (Processo p in Processos)
            {
                if (p.GetAlocado() == 0)
                {
                    auxN = new ProcessoN(p.GetId(), p.GetComputacao());
                    ProcessosNALOCADOS.Add(auxN);
                }
            }

            EscreverArquivo("WORST-FIT");
        }

        public static void EscreverArquivo(string algoritmo)
        {
            a.ArquivoSaida("Algoritmo " + algoritmo + "\r\n", algoritmo);

            foreach (Memoria m in MemoriaLIDA)
            {
                a.ArquivoSaida(m.ToString(), algoritmo);
            }

            a.ArquivoSaida("\r\nPROCESSOS NÃO ALOCADOS / TAMANHO", algoritmo);

            foreach (ProcessoN pnl in ProcessosNALOCADOS)
            {
                a.ArquivoSaida(pnl.ToString(), algoritmo);
            }
        }

        public static void ResetDATA()
        {
            MemoriaLIDA = new List<Memoria>((IEnumerable<Memoria>)a.LerArquivo(txtMemoria));
            ProcessosLIDOS = new List<Processo>((IEnumerable<Processo>)a.LerArquivo(txtProcessos));
            ProcessosNALOCADOS = new List<ProcessoN>();
        }
    }
}

